ALTER TABLE `jos_phd_applicants` ADD `docs_checked` BOOLEAN NOT NULL;
ALTER TABLE `jos_phd_applicants` ADD `missing_docs` TEXT NOT NULL;
ALTER TABLE `jos_phd_applicants` ADD `academic_comments` TEXT NOT NULL; 
ALTER TABLE `jos_phd_applicants` ADD `applicant_contacted` BOOLEAN NOT NULL; 
ALTER TABLE `jos_phd_applicants` ADD `applicant_contacted_date` DATE NOT NULL; 
ALTER TABLE `jos_phd_applicants` ADD `indian` BOOLEAN NOT NULL;
ALTER TABLE `jos_phd_applicants` ADD `indian_info` TEXT NOT NULL;
ALTER TABLE `jos_phd_applicants` ADD `scientific_discipline_id` INT( 11 ) NOT NULL;